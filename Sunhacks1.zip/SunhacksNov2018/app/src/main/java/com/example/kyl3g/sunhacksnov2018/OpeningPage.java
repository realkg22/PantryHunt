package com.example.kyl3g.sunhacksnov2018;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class OpeningPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_opening);
    }
}
